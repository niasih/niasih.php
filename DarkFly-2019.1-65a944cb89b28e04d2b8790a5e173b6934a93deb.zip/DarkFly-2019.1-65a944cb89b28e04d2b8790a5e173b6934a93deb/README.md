# DarkFly-2019.1

DarkFly-2019.1 generation of DarkFly-tools, this tools is a super power, open source, fast, and automatic tools
add your favorite github users and download repository via DarkFly-2019.1, add more github users and find another tools from DarkFly-2019.1


INDONESIA:<br>
DarkFly-2019.1 generasi dari DarkFly-tools,
tambahkan pengguna github kesukaan kalian kedalam tools DarkFly-2019.1 dan Temukan ribuan tools lainya yang selalu update

# Screenshoot

![1](https://github.com/Ranginang67/DarkFly-2019.1/blob/master/example/1.png)


* **install on Linux (as superuser)**

```
#apt-get install git
#git clone https://github.com/Ranginang67/DarkFly-2019.1
#cd DarkFly-2019.1
#chmod +x install.py
#python3 install.py install
#DarkFly.
```

* **install on Termux android**

```
$pkg install git python -y
$git clone https://github.com/Ranginang67/DarkFly-2019.1
$cd DarkFly-2019.1
$chmod +x install.py
$python install.py install
$DarkFly.
```
